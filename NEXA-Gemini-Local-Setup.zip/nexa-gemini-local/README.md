# NEXA + Gemini (local setup)

This package runs the NEXA HTML interface and a small Node.js backend on your own computer. The backend keeps the Gemini API key out of browser JavaScript.

## 1) Install Node.js

Install the current **LTS** version from https://nodejs.org/en/download/ . After installation, open a NEW terminal and check:

```bash
node -v
npm -v
```

## 2) Get a Gemini API key

1. Open https://aistudio.google.com/ and sign in.
2. Open the API Keys page and create a key.
3. Keep the key private. Do not paste it into `public/index.html`, screenshots, chats, or public repositories.

The free tier has usage limits and model availability can change; check the usage/limits shown in AI Studio.

## 3) Add your key

In this project folder, make a copy of `.env.example` named `.env`.
Open `.env` and replace `PASTE_YOUR_KEY_HERE` with your key, for example:

```env
GEMINI_API_KEY=your_real_key_here
PORT=3000
```

Do not include quotes unless the key requires them. Do not share the `.env` file. It is excluded by `.gitignore`.

## 4) Install dependencies and start NEXA

Open Terminal / PowerShell **inside this folder** and run:

```bash
npm install
npm start
```

Then open **http://127.0.0.1:3000** in your browser. Do not open `public/index.html` directly by double-clicking it; use the local address above so `/api/chat` reaches the backend.

To stop the server, focus the terminal and press `Ctrl+C`.

## Troubleshooting

- **`node` is not recognized:** install Node.js LTS, close and reopen the terminal.
- **Key missing:** confirm the file is named exactly `.env` (not `.env.txt`) and restart `npm start`.
- **Quota / API error:** check AI Studio's API usage and model limits; free access is not unlimited.
- **Port busy:** change `PORT=3001` in `.env`, restart, then visit `http://127.0.0.1:3001`.

## Security notes

- The server binds to `127.0.0.1`, so it is intended for use on this computer only.
- The API key is read from `.env` on the server and is never sent to the webpage.
- Do not expose this development server publicly. A public deployment needs hosting, access controls, abuse protection, and server-side secret configuration.
