import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.GEMINI_API_KEY?.trim();

app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// This local starter deliberately binds only to this computer.
const ai = apiKey && apiKey !== 'PASTE_YOUR_KEY_HERE'
  ? new GoogleGenAI({ apiKey })
  : null;

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, apiKeyConfigured: Boolean(ai) });
});

app.post('/api/chat', async (req, res) => {
  if (!ai) {
    return res.status(503).json({
      error: 'Gemini API key is missing. Add it to your .env file, then restart NEXA.'
    });
  }

  const message = typeof req.body?.message === 'string'
    ? req.body.message.trim()
    : '';
  if (!message) {
    return res.status(400).json({ error: 'Please enter a message.' });
  }
  if (message.length > 12000) {
    return res.status(413).json({ error: 'That message is too long. Try a shorter one.' });
  }

  // NEXA stores messages as { role: 'user'|'assistant', content: '...' }.
  // Keep a short recent history so follow-up questions have context.
  const rawMessages = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const history = rawMessages
    .filter((item) => item && ['user', 'assistant'].includes(item.role)
      && typeof item.content === 'string')
    .slice(-20)
    .map((item) => ({
      role: item.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: item.content.slice(0, 12000) }]
    }));

  // Gemini expects the conversation to begin with a user message.
  while (history.length && history[0].role === 'model') history.shift();

  // If the frontend did not include the current user message in history, add it.
  const last = history.at(-1);
  if (!last || last.role !== 'user' || last.parts[0].text !== message) {
    history.push({ role: 'user', parts: [{ text: message }] });
  }

  try {
    const result = await ai.models.generateContent({
      model: 'gemini-flash-latest',
      contents: history,
      config: {
        systemInstruction: 'You are NEXA, a helpful, friendly AI assistant. Answer clearly and accurately. If you are unsure, say so. Use concise formatting unless the user asks for detail.'
      }
    });

    const reply = result.text?.trim();
    if (!reply) {
      return res.status(502).json({ error: 'Gemini returned an empty reply. Please try again.' });
    }
    return res.json({ reply });
  } catch (error) {
    // Log a safe summary only; never log the API key or request headers.
    console.error('Gemini request failed:', error?.status || '', error?.message || 'Unknown error');
    return res.status(502).json({
      error: 'Gemini could not answer right now. Check your API key, internet connection, and API quota, then try again.'
    });
  }
});

app.listen(port, '127.0.0.1', () => {
  console.log(`NEXA is running at http://127.0.0.1:${port}`);
  if (!ai) console.log('Setup needed: copy .env.example to .env and add your Gemini API key.');
});
